import random
import sys
import math
import pygame
import os

WIDTH = 1100
HEIGHT = 700
FPS = 60

COLORS = {
    "bg": (255, 242, 242),
    "berry_red": (226, 45, 76),
    "cream": (255, 253, 247),
    "mint_green": (156, 210, 159),
    "text": (90, 35, 43),
    "shadow": (200, 140, 145),
    "accent": (255, 213, 128),
    "skin_tone": (255, 224, 196),
    "lemon_yellow": (255, 230, 100),
    "orange_color": (255, 140, 50),
    "raspberry_pink": (220, 60, 120),
    "plum_purple": (142, 68, 173),
    "blueberry_blue": (41, 128, 185),
    "cherry_magenta": (192, 57, 43),
    "huck_teal": (22, 160, 133),
    "sweet_lavender": (210, 180, 222),
    "sour_lime": (139, 195, 74),
    "apple_green": (198, 239, 206),

    # Cake Batter Colors
    "cake_Chocolate": (74, 40, 31), "cake_Vanilla": (249, 227, 184),
    "cake_Strawberry": (245, 151, 166), "cake_Carrot Cake": (219, 114, 53),
    "cake_Red Velvet": (150, 24, 38), "cake_Blueberry Blast": (74, 103, 171),
    "cake_Lemon Chiffon": (255, 244, 150), "cake_Coffee Mocha": (115, 84, 64),
    "cake_Mint Choc Chip": (174, 235, 200), "cake_Coconut Cream": (250, 248, 242),
    "cake_Matcha Velvet": (76, 115, 80), "cake_Salted Caramel": (194, 121, 62),
    "cake_Ruby Chocolate": (186, 76, 111), "cake_Mango Tango": (245, 179, 66),
    "cake_Pistachio Bliss": (164, 209, 136), "cake_Lavender Dream": (170, 147, 214),
    "cake_Golden Saffron Splendor": (232, 180, 46), "cake_Pink Diamond Truffle": (214, 124, 168),
    "cake_Royal Empress Ube": (104, 52, 156), "cake_Cosmic Stardust Vanilla": (48, 43, 99),

    # Frosting Colors
    "frost_Buttercream": (255, 249, 214), "frost_Cream Cheese": (247, 244, 230),
    "frost_Fudge Glaze": (48, 25, 19), "frost_Lemon Cream": (255, 250, 190),
    "frost_Rosewater Glaze": (247, 193, 204), "frost_Peanut Butter": (219, 161, 99),
    # Unlockable Frosting Colors
    "frost_Whipped Cream": (250, 250, 255), "frost_Caramel Drizzle": (196, 127, 42),
    "frost_Strawberry Glaze": (255, 130, 150), "frost_Maple Frosting": (200, 128, 60),
    "frost_Chocolate Ganache": (40, 20, 10), "frost_Vanilla Bean Glaze": (245, 235, 200),
    # New Unlockable Cake Colors
    "cake_Tiramisu Dream": (200, 180, 150), "cake_Black Forest": (40, 15, 25),
    "cake_Caramel Apple": (205, 133, 63), "cake_Peach Melba": (255, 185, 120),
    "cake_Raspberry Cheesecake": (220, 80, 130), "cake_Tropical Paradise": (100, 210, 180),
    "cake_Dark Cherry Noir": (100, 20, 40), "cake_Earl Grey Honey": (200, 195, 170),
    "cake_Cinnamon Roll": (180, 100, 40), "cake_Smores Delight": (90, 70, 50)
}

FLAVORS = [
    "Chocolate", "Vanilla", "Strawberry", "Carrot Cake", "Red Velvet",
    "Blueberry Blast", "Lemon Chiffon", "Coffee Mocha", "Mint Choc Chip", "Coconut Cream",
    "Matcha Velvet", "Salted Caramel", "Ruby Chocolate", "Mango Tango", "Pistachio Bliss",
    "Lavender Dream", "Golden Saffron Splendor", "Pink Diamond Truffle", "Royal Empress Ube", "Cosmic Stardust Vanilla",
    "Tiramisu Dream", "Black Forest", "Caramel Apple", "Peach Melba", "Raspberry Cheesecake",
    "Tropical Paradise", "Dark Cherry Noir", "Earl Grey Honey", "Cinnamon Roll", "Smores Delight"
]
ALL_FROSTINGS = [
    "Buttercream", "Cream Cheese", "Fudge Glaze", "Lemon Cream", "Rosewater Glaze", "Peanut Butter",
    "Whipped Cream", "Caramel Drizzle", "Strawberry Glaze", "Maple Frosting", "Chocolate Ganache", "Vanilla Bean Glaze"
]
FROSTINGS = ALL_FROSTINGS  # kept for backwards compat; runtime uses self.unlocked_frostings
ALL_GARNISHES = [
    "Fresh Berries", "Sprinkles", "Mint Leaves", "Rainbow Sprink", "Choc Chips", "White Choc Curl",
    "Edible Flowers", "Gold Dust", "Crushed Oreo", "Caramel Swirl", "Candied Nuts", "Macaroon Crumble"
]
GARNISHES = ALL_GARNISHES  # kept for backwards compat; runtime uses self.unlocked_garnishes

CHARACTERS = [
    {"name": "Strawberry Shortcake", "color": COLORS["berry_red"], "hair": (240, 80, 90), "lines": ["Hey {name}! Let's make something berry spectacular!", "Hi {name}! Can you whip up my favorite look?"]},
    {"name": "Lemon Meringue", "color": COLORS["lemon_yellow"], "hair": (255, 230, 50), "lines": ["Hello {name}! This order needs to look totally stylish!", "Hey {name}, design this sweet style for me!"]},
    {"name": "Orange Blossom", "color": COLORS["orange_color"], "hair": (100, 60, 30), "lines": ["Hiya {name}! Something bright and cheerful, please!", "Hey {name}! Can we bake a little ray of sunshine?"]},
    {"name": "Raspberry Torte", "color": COLORS["raspberry_pink"], "hair": (200, 40, 140), "lines": ["Greetings {name}. Make sure this looks totally runway-ready!", "Hi {name}, darling. I need a glamorous treat."]},
    {"name": "Plum Pudding", "color": COLORS["plum_purple"], "hair": (80, 40, 120), "lines": ["Hey {name}! Let's keep the rhythm going with a sweet treat!", "Five, six, seven, eight! Ready to bake, {name}?"]},
    {"name": "Blueberry Muffin", "color": COLORS["blueberry_blue"], "hair": (30, 80, 180), "lines": ["Hi {name}! Reading books makes me hungry for something sweet.", "According to my calculations, {name}, this will taste amazing!"]},
    {"name": "Cherry Jam", "color": COLORS["cherry_magenta"], "hair": (140, 20, 50), "lines": ["Hey {name}! This order is gonna be an absolute rock hit!", "Can you put a little musical sparkle on this cake, {name}?"]},
    {"name": "Huckleberry Pie", "color": COLORS["huck_teal"], "hair": (120, 90, 60), "lines": ["What's up, {name}? Baking is almost as fun as skateboarding!", "Hey {name}, hope you don't mind a little mess on this order!"]},
    {"name": "Sweet Grapes", "color": COLORS["sweet_lavender"], "hair": (190, 140, 220), "lines": ["Um, hello {name}... I'd love a sweet treat if it's no trouble.", "Hi {name}! Something gentle and sugary would be lovely."]},
    {"name": "Sour Grapes", "color": COLORS["sour_lime"], "hair": (110, 160, 50), "lines": ["Fine, {name}. Make it quick, I don't have all day.", "Ugh, {name}... just give me something covered in frosting."]},
    {"name": "Apple Dumplin'", "color": COLORS["apple_green"], "hair": (230, 160, 90), "lines": ["Apple-tastic! Hi {name}! Big bakes for small bites!", "Hehe, {name}! Can you add extra toppings for me?"]}
]

BADGES_REQUIREMENTS = [
    {"title": "First Step", "desc": "Earn $20", "type": "money", "goal": 20},
    {"title": "Baking Rookie", "desc": "Earn $50", "type": "money", "goal": 50},
    {"title": "Cafe Artisan", "desc": "Earn $150", "type": "money", "goal": 150},
    {"title": "Pastry Executive", "desc": "Earn $300", "type": "money", "goal": 300},
    {"title": "Bitty Tycoon", "desc": "Earn $500", "type": "money", "goal": 500},
    {"title": "Berry Millionaire", "desc": "Earn $1000", "type": "money", "goal": 1000},
    {"title": "Capitalist Roll", "desc": "Earn $2000", "type": "money", "goal": 2000},
    {"title": "Sparkle Baker", "desc": "Score 100 pts", "type": "score", "goal": 100},
    {"title": "Grand Patissier", "desc": "Score 500 pts", "type": "score", "goal": 500},
    {"title": "Baking Legend", "desc": "Score 1500 pts", "type": "score", "goal": 1500},
    {"title": "Kitchen Overlord", "desc": "Score 3000 pts", "type": "score", "goal": 3000},
    {"title": "Warm Up Streak", "desc": "3 Combo Streak", "type": "combo", "goal": 3},
    {"title": "Steady Hands", "desc": "5 Combo Streak", "type": "combo", "goal": 5},
    {"title": "Flawless Baker", "desc": "8 Combo Streak", "type": "combo", "goal": 8},
    {"title": "Combo Master", "desc": "12 Combo Streak", "type": "combo", "goal": 12},
    {"title": "Unstoppable Chef", "desc": "20 Combo Streak", "type": "combo", "goal": 20},
    {"title": "Gourmet Novice", "desc": "Unlock 3 Flavors", "type": "flavors_count", "goal": 3},
    {"title": "Flavor Explorer", "desc": "Unlock 5 Flavors", "type": "flavors_count", "goal": 5},
    {"title": "Master Blender", "desc": "Unlock 8 Flavors", "type": "flavors_count", "goal": 8},
    {"title": "Menu Complete", "desc": "Unlock 15 Flavors", "type": "flavors_count", "goal": 15},
    {"title": "Elite Connoisseur", "desc": "Unlock All 30 Flavors", "type": "flavors_count", "goal": 30},
    {"title": "Frosting Artisan", "desc": "Unlock 6 Frostings", "type": "frostings_count", "goal": 6},
    {"title": "Master Pastry Chef", "desc": "Unlock All 12 Frostings", "type": "frostings_count", "goal": 12},
    {"title": "Topping Expert", "desc": "Unlock 6 Toppings", "type": "garnishes_count", "goal": 6},
    {"title": "Garnish Grandmaster", "desc": "Unlock All 12 Toppings", "type": "garnishes_count", "goal": 12},
    {"title": "Industrialist", "desc": "Buy 5 Market Upgrades", "type": "upgrades_count", "goal": 5},
    {"title": "Cafe Renovator", "desc": "Buy 10 Market Upgrades", "type": "upgrades_count", "goal": 10},
    {"title": "Baking Emperor", "desc": "Buy 18 Market Upgrades", "type": "upgrades_count", "goal": 18},
    {"title": "100% Completion", "desc": "Buy All 25 Upgrades", "type": "upgrades_count", "goal": 25}
]

class BakeryGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Strawberry Shortcake: Berry Bitty Empire")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.is_web_runtime = sys.platform == "emscripten"

        available_fonts = pygame.font.get_fonts()
        font_selection = "Comic Sans MS"
        for preferred in ["curlzmt", "harrington", "gabriola", "lucidahandwriting", "segoeui"]:
            if preferred in available_fonts:
                font_selection = preferred
                break

        self.font = self.make_font(15, preferred=font_selection)
        self.small_font = self.make_font(17, preferred=font_selection)
        self.tiny_font = self.make_font(12, bold=True, preferred="Arial")
        self.title_font = self.make_font(36, bold=True, preferred=font_selection)
        self.badge_desc_font = self.make_font(10, preferred="Arial")
        self.shop_desc_font = self.make_font(11, italic=True, preferred="Arial")
        self.dash_font = self.make_font(14, italic=True, preferred="Arial")

        # Robust directory path resolving engine for mobile devices
        try:
            self.script_dir = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            self.script_dir = os.getcwd()

        self.intro_background = None
        bg_path = None
        for candidate in [
            "strawberry-shortcake-background.jpg",
            "strawberry_shortcake_background.jpg",
            "StrawBerry SHort Cake Background .jpg",
        ]:
            bg_path = self.find_asset_file(candidate)
            if bg_path:
                break
        if bg_path:
            try:
                loaded_bg = pygame.image.load(bg_path).convert()
                self.intro_background = pygame.transform.scale(loaded_bg, (WIDTH, HEIGHT))
            except Exception as e:
                print(f"Error scaling background visual asset: {e}")

        # High-Quality Character Asset Loading System
        self.loaded_character_images = []
        for filename in [
            "strawberry-shortcake.jpg",
            "strawberry_shortcake.jpg",
            "StrawBerry Short Cake .jpg",
            "download.jpg",
        ]:
            path = self.find_asset_file(filename)
            if path:
                try:
                    img = pygame.image.load(path).convert_alpha()
                    self.loaded_character_images.append(img)
                except Exception as e:
                    print(f"Error loading {filename}: {e}")

        self.reset_game_state()

    def find_asset_file(self, filename):
        search_paths = [
            os.path.join(self.script_dir, filename),
            os.path.join(os.getcwd(), filename),
            filename
        ]
        for path in search_paths:
            if os.path.exists(path):
                return path
        # Case insensitive secondary lookup loop
        for folder in [self.script_dir, os.getcwd()]:
            if os.path.exists(folder):
                try:
                    for item in os.listdir(folder):
                        if item.lower() == filename.lower():
                            return os.path.join(folder, item)
                except Exception:
                    pass
        return None

    def make_font(self, size, bold=False, italic=False, preferred=None):
        candidates = []
        if preferred:
            candidates.append(preferred)
        candidates.extend(["Comic Sans MS", "Arial", "Verdana"])
        for name in candidates:
            try:
                return pygame.font.SysFont(name, size, bold=bold, italic=italic)
            except Exception:
                continue
        return pygame.font.Font(None, size)

    def reset_game_state(self):
        self.buttons = []
        self.score = 0
        self.money = 0
        self.shift_max_time = 90
        self.time_left = self.shift_max_time
        self.combo = 0
        self.shop_scroll_offset = 0
        self.shop_right_tab = "flavors"   # Options: flavors, frostings, garnishes
        self.shop_right_scroll = 0
        self.active_sidebar_tab = "sponge" # Options: sponge, frosting, garnish
        self.sponge_page = 0 # Page 0/1/2 (10 flavors each)

        self.baker_name = "Baker Sweetie"
        self.typing_active = False

        self.upgrades = {
            "planter": {"name": "Strawberry Planter", "cost": 40, "desc": "Auto generates +$2/sec", "active": False},
            "whisk": {"name": "Golden Whisk", "cost": 60, "desc": "Double match rewards points", "active": False},
            "rug": {"name": "Cozy Pink Rug", "cost": 30, "desc": "Redesign cozy room aesthetic", "active": False},
            "espresso": {"name": "Espresso Machine", "cost": 75, "desc": "Halves patience drainage", "active": False},
            "apron": {"name": "Silk Baking Apron", "cost": 45, "desc": "+$1 bonus on serving cakes", "active": False},
            "timer": {"name": "Digital Wall Clock", "cost": 80, "desc": "Extends day shifts by +15s", "active": False},
            "frosting_gun": {"name": "Turbo Piping Gun", "cost": 95, "desc": "+$2 bonus per perfect frosting", "active": False},
            "sprinkle_dispenser": {"name": "Auto Sprinkle Shaker", "cost": 110, "desc": "+10% patience on service", "active": False},
            "neon_sign": {"name": "Bright Cafe Neon Sign", "cost": 140, "desc": "Customers tip +$3 more", "active": False},
            "radio": {"name": "Jukebox Speaker", "cost": 160, "desc": "Slows patience loss by 10%", "active": False},
            "display_case": {"name": "Glass Pastry Tower", "cost": 180, "desc": "Generates +$4/sec passively", "active": False},
            "conveyor": {"name": "Frosting Belt Belt", "cost": 220, "desc": "Increases server score by +5", "active": False},
            "assistant": {"name": "Baking Assistant Robo", "cost": 260, "desc": "Tips increased by +15%", "active": False},
            "fridge": {"name": "Subzero Blast Cooler", "cost": 300, "desc": "Patience completely frozen for 1st customer", "active": False},
            "mixing_bowl": {"name": "Titanium Mixing Vat", "cost": 350, "desc": "+$5 flat score bonus per match", "active": False},
            "ovens": {"name": "Quad-Core Brick Oven", "cost": 410, "desc": "Passively earns +$8/sec", "active": False},
            "packaging": {"name": "Luxury Satin Bow Boxes", "cost": 480, "desc": "Serving premium orders gives +$10", "active": False},
            "insurance": {"name": "Bakery Liability Shield", "cost": 550, "desc": "Wrong orders lose $0 instead of $5", "active": False},
            "ads": {"name": "Cottage Flyer Campaign", "cost": 620, "desc": "Max patience levels increased to 120%", "active": False},
            "solar": {"name": "Eco Solar Bakery Roof", "cost": 700, "desc": "Halves the cost of flavor stocks", "active": False},
            "drone": {"name": "Berry Drone Delivery", "cost": 800, "desc": "Passively generates +$15/sec", "active": False},
            "gold_plated": {"name": "Gold-Leaf Rolling Pin", "cost": 900, "desc": "Double total cash rewards at shift end", "active": False},
            "chandelier": {"name": "Diamond Crystal Lights", "cost": 1000, "desc": "Customers start with maximum bonus bars", "active": False},
            "cosmic_oven": {"name": "Cosmic Antimatter Oven", "cost": 1200, "desc": "Passively yields +$35/sec", "active": False},
            "empire_license": {"name": "Global Franchise License", "cost": 1500, "desc": "Unlocks hidden corporate end game rewards", "active": False}
        }

        self.unlocked_flavors = ["Chocolate", "Vanilla", "Strawberry"]
        self.flavor_costs = {
            "Carrot Cake": 45, "Red Velvet": 50, "Blueberry Blast": 60, "Lemon Chiffon": 65, "Coffee Mocha": 70,
            "Mint Choc Chip": 75, "Coconut Cream": 80, "Matcha Velvet": 120, "Salted Caramel": 140, "Ruby Chocolate": 180,
            "Mango Tango": 200, "Pistachio Bliss": 240, "Lavender Dream": 280, "Golden Saffron Splendor": 350,
            "Pink Diamond Truffle": 400, "Royal Empress Ube": 450, "Cosmic Stardust Vanilla": 500,
            "Tiramisu Dream": 55, "Black Forest": 65, "Caramel Apple": 70, "Peach Melba": 80,
            "Raspberry Cheesecake": 90, "Tropical Paradise": 110, "Dark Cherry Noir": 130,
            "Earl Grey Honey": 160, "Cinnamon Roll": 190, "Smores Delight": 220
        }
        self.unlocked_frostings = ["Buttercream", "Cream Cheese", "Fudge Glaze"]
        self.frosting_costs = {
            "Lemon Cream": 35, "Rosewater Glaze": 45, "Peanut Butter": 55,
            "Whipped Cream": 70, "Caramel Drizzle": 90, "Strawberry Glaze": 110,
            "Maple Frosting": 130, "Chocolate Ganache": 160, "Vanilla Bean Glaze": 200
        }
        self.unlocked_garnishes = ["Fresh Berries", "Sprinkles", "Mint Leaves"]
        self.garnish_costs = {
            "Rainbow Sprink": 30, "Choc Chips": 40, "White Choc Curl": 55,
            "Edible Flowers": 75, "Gold Dust": 100, "Crushed Oreo": 120,
            "Caramel Swirl": 145, "Candied Nuts": 170, "Macaroon Crumble": 210
        }

        self.num_slots = 3
        self.active_slots = []
        for _ in range(self.num_slots):
            self.active_slots.append(self.generate_new_line_customer())
        self.selected_slot_index = 0

        self.selected_flavor = None
        self.selected_frosting = None
        self.selected_garnish = None

        self.message = "Welcome to your dream cafe!"
        self.last_tick = pygame.time.get_ticks()
        self.game_over = False
        self.show_intro = True
        self.show_badge_tab_phase = False
        self.show_shop_phase = False
        self.is_paused = False
        self.anim_tick = 0
        self.unlocked_badges_cache = set()

    def generate_new_line_customer(self):
        cust = random.choice(CHARACTERS)
        available_order_flavors = self.unlocked_flavors if self.unlocked_flavors else ["Vanilla"]
        available_frostings = self.unlocked_frostings if self.unlocked_frostings else ["Buttercream"]
        available_garnishes = self.unlocked_garnishes if self.unlocked_garnishes else ["Fresh Berries"]
        order = {
            "flavor": random.choice(available_order_flavors),
            "frosting": random.choice(available_frostings),
            "garnish": random.choice(available_garnishes)
        }
        base_line = random.choice(cust["lines"])
        dialogue = base_line.format(name=self.baker_name)
        return {
            "profile": cust,
            "order": order,
            "patience": 120 if self.upgrades["ads"]["active"] else 100,
            "dialogue": dialogue
        }

    def count_active_upgrades(self):
        return sum(1 for u in self.upgrades.values() if u["active"])

    def evaluate_order(self, flavor, frosting, garnish):
        active_order = self.active_slots[self.selected_slot_index]["order"]
        patience = self.active_slots[self.selected_slot_index]["patience"]
        correct = (flavor == active_order["flavor"] and frosting == active_order["frosting"] and garnish == active_order["garnish"])

        if correct:
            self.combo += 1
            patience_bonus = int(patience / 10)
            reward = 20 + self.combo * 3 + patience_bonus

            if self.upgrades["whisk"]["active"]: reward *= 2
            if self.upgrades["apron"]["active"]: reward += 1
            if self.upgrades["frosting_gun"]["active"]: reward += 2
            if self.upgrades["neon_sign"]["active"]: reward += 3
            if self.upgrades["assistant"]["active"]: reward = int(reward * 1.15)
            if self.upgrades["packaging"]["active"] and flavor in ["Golden Saffron Splendor", "Pink Diamond Truffle", "Royal Empress Ube", "Cosmic Stardust Vanilla"]: reward += 10
            if self.upgrades["gold_plated"]["active"]: reward *= 2

            self.money += reward
            self.score += reward
            self.message = f"Berry Perfect Match! +${reward}"
            self.check_badges()
            return True
        else:
            self.combo = 0
            loss = 0 if self.upgrades["insurance"]["active"] else 5
            self.money = max(0, self.money - loss)
            self.message = "Oh no, that wasn't the right style!"
            return False

    def next_slot_order(self, index):
        self.active_slots[index] = self.generate_new_line_customer()
        if index == self.selected_slot_index:
            self.selected_flavor = None
            self.selected_frosting = None
            self.selected_garnish = None

    def check_badges(self):
        upgrades_count = self.count_active_upgrades()
        for b in BADGES_REQUIREMENTS:
            title = b["title"]
            if title in self.unlocked_badges_cache:
                continue
            unlocked = False
            if b["type"] == "money" and self.money >= b["goal"]: unlocked = True
            elif b["type"] == "score" and self.score >= b["goal"]: unlocked = True
            elif b["type"] == "combo" and self.combo >= b["goal"]: unlocked = True
            elif b["type"] == "flavors_count" and len(self.unlocked_flavors) >= b["goal"]: unlocked = True
            elif b["type"] == "frostings_count" and len(self.unlocked_frostings) >= b["goal"]: unlocked = True
            elif b["type"] == "garnishes_count" and len(self.unlocked_garnishes) >= b["goal"]: unlocked = True
            elif b["type"] == "upgrades_count" and upgrades_count >= b["goal"]: unlocked = True

            if unlocked:
                self.unlocked_badges_cache.add(title)
                self.message = f"🏆 Badge Unlocked: {title}!"

    def draw_button(self, rect, text, color, text_color=COLORS["text"], action=None):
        mouse_pos = pygame.mouse.get_pos()
        hovered = rect.collidepoint(mouse_pos)
        draw_color = tuple(min(255, c + 15) for c in color) if hovered else color
        pygame.draw.rect(self.screen, draw_color, rect, border_radius=8)
        pygame.draw.rect(self.screen, COLORS["shadow"], rect, 1, border_radius=8)
        label = self.tiny_font.render(text, True, text_color)
        self.screen.blit(label, label.get_rect(center=rect.center))
        if action:
            self.buttons.append((rect, action))

    def draw_panel(self, x, y, w, h, title=""):
        panel = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLORS["cream"], panel, border_radius=24)
        pygame.draw.rect(self.screen, COLORS["mint_green"], panel, 4, border_radius=24)
        if title:
            self.screen.blit(self.font.render(title, True, COLORS["berry_red"]), (x + 20, y + 14))
        return panel

    def draw_character_slot(self, cx, cy, character_data, size="large"):
        # HIGH QUALITY GRAPHICS OVERLAY ENGINE
        if self.loaded_character_images:
            char_name = character_data.get("name", "")
            img_idx = abs(hash(char_name)) % len(self.loaded_character_images)
            base_img = self.loaded_character_images[img_idx]

            if size == "large":
                bounce = math.sin(self.anim_tick * 1.5) * 4 if not self.is_paused else 0
                scaled_img = pygame.transform.scale(base_img, (110, 140))
                self.screen.blit(scaled_img, (cx - 55, cy - 55 + bounce))
            else:
                scaled_img = pygame.transform.scale(base_img, (55, 70))
                self.screen.blit(scaled_img, (cx - 27, cy - 30))
        else:
            # Fallback high quality vector rendering if assets are not loaded
            scale = 1.0 if size == "large" else 0.5
            hair_color = character_data.get("hair", (200, 50, 50))
            outfit_color = character_data.get("color", COLORS["berry_red"])
            bounce = math.sin(self.anim_tick * 1.5) * 4 if (not self.is_paused and size == "large") else 0
            y_offset = cy + bounce

            body_poly = [
                (cx - int(18*scale), y_offset + int(50*scale)),
                (cx + int(18*scale), y_offset + int(50*scale)),
                (cx + int(8*scale), y_offset + int(20*scale)),
                (cx - int(8*scale), y_offset + int(20*scale))
            ]
            pygame.draw.polygon(self.screen, outfit_color, body_poly)
            pygame.draw.circle(self.screen, hair_color, (cx, int(y_offset + 5*scale)), int(18*scale))
            pygame.draw.circle(self.screen, COLORS["skin_tone"], (cx, int(y_offset)), int(14*scale))

    def draw_pastry_visual(self, cx, cy):
        if not self.selected_flavor:
            txt = self.dash_font.render("[ Choose Flavor ]", True, COLORS["shadow"])
            self.screen.blit(txt, txt.get_rect(center=(cx, cy)))
            return

        cake_color = COLORS.get(f"cake_{self.selected_flavor}", COLORS["cake_Vanilla"])
        pygame.draw.rect(self.screen, cake_color, (cx-45, cy-15, 90, 45), border_radius=6)

        if self.selected_frosting:
            f_color = COLORS.get(f"frost_{self.selected_frosting}", COLORS["cream"])
            pygame.draw.rect(self.screen, f_color, (cx-45, cy+2, 90, 6))
            pygame.draw.rect(self.screen, f_color, (cx-45, cy-22, 90, 8), border_radius=2)

        if self.selected_garnish:
            if self.selected_garnish == "Fresh Berries":
                pygame.draw.circle(self.screen, COLORS["berry_red"], (cx-10, cy-26), 6)
                pygame.draw.circle(self.screen, COLORS["berry_red"], (cx+10, cy-24), 5)
            elif self.selected_garnish in ["Sprinkles", "Rainbow Sprink"]:
                spr_colors = [(255, 105, 180), (0, 206, 209), (255, 215, 0), (150, 50, 250)]
                for i, color in enumerate(spr_colors[:3] if self.selected_garnish == "Sprinkles" else spr_colors):
                    pygame.draw.rect(self.screen, color, (cx - 25 + (i * 12), cy - 24, 5, 3))
            elif self.selected_garnish == "Mint Leaves":
                pygame.draw.ellipse(self.screen, COLORS["mint_green"], (cx-12, cy-28, 14, 8))
            elif self.selected_garnish == "Choc Chips":
                pygame.draw.circle(self.screen, (50, 30, 20), (cx-15, cy-25), 3)
                pygame.draw.circle(self.screen, (50, 30, 20), (cx, cy-26), 3)
            elif self.selected_garnish == "White Choc Curl":
                pygame.draw.ellipse(self.screen, (245, 240, 230), (cx-10, cy-26, 20, 5), 1)
            elif self.selected_garnish == "Edible Flowers":
                pygame.draw.circle(self.screen, (255, 150, 200), (cx, cy-26), 5)
                pygame.draw.circle(self.screen, (255, 220, 100), (cx, cy-26), 2)
            elif self.selected_garnish == "Gold Dust":
                for gd in range(6):
                    pygame.draw.circle(self.screen, (255, 215, 0), (cx - 18 + gd * 7, cy - 25), 2)
            elif self.selected_garnish == "Crushed Oreo":
                pygame.draw.rect(self.screen, (20, 15, 10), (cx - 20, cy - 27, 40, 5))
            elif self.selected_garnish == "Caramel Swirl":
                pygame.draw.arc(self.screen, (196, 127, 42), (cx - 12, cy - 30, 24, 10), 0, 3.14, 3)
            elif self.selected_garnish == "Candied Nuts":
                for cn in range(4):
                    pygame.draw.circle(self.screen, (160, 100, 40), (cx - 15 + cn * 10, cy - 26), 3)
            elif self.selected_garnish == "Macaroon Crumble":
                for mc in range(3):
                    pygame.draw.circle(self.screen, (255, 210, 180), (cx - 10 + mc * 10, cy - 26), 4)

    def draw(self):
        current_bg = (255, 210, 220) if self.upgrades["rug"]["active"] else COLORS["bg"]
        self.screen.fill(current_bg)
        if not self.is_paused:
            self.anim_tick += 0.05
        self.buttons = []

        # 1. INTRO SCREEN
        if self.show_intro:
            if self.intro_background:
                self.screen.blit(self.intro_background, (0, 0))
            else:
                self.screen.fill((255, 200, 210))

            overlay = pygame.Rect(WIDTH // 2 - 300, HEIGHT // 2 - 220, 600, 440)
            pygame.draw.rect(self.screen, (255, 255, 255, 240), overlay, border_radius=28)
            pygame.draw.rect(self.screen, COLORS["berry_red"], overlay, 4, border_radius=28)

            title = self.title_font.render("Berry Bitty Bakery Cafe", True, COLORS["berry_red"])
            self.screen.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 140)))

            lbl = self.small_font.render("Tap box to type Name Tag:", True, COLORS["text"])
            self.screen.blit(lbl, lbl.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))

            tag_rect = pygame.Rect(WIDTH // 2 - 175, HEIGHT // 2 - 20, 350, 50)
            box_border_color = COLORS["berry_red"] if self.typing_active else COLORS["shadow"]
            pygame.draw.rect(self.screen, COLORS["accent"] if self.typing_active else COLORS["cream"], tag_rect, border_radius=12)
            pygame.draw.rect(self.screen, box_border_color, tag_rect, 2, border_radius=12)

            name_text = self.small_font.render(self.baker_name + ("|" if self.typing_active else ""), True, COLORS["text"])
            self.screen.blit(name_text, name_text.get_rect(center=tag_rect.center))
            self.buttons.append((tag_rect, "activate_typing"))

            self.draw_button(pygame.Rect(WIDTH // 2 - 140, HEIGHT // 2 + 80, 280, 60), "🍓 Start Cooking Shift 🍓", COLORS["berry_red"], COLORS["cream"], action="start_game")
            return

        # 2. REVIEW BADGES TRACKER SCREEN
        if self.show_badge_tab_phase:
            self.draw_panel(40, 40, 1020, 620, "✨ Day Review: Badges Tracker ✨")

            badge_box_x = 60
            badge_box_y = 100
            for idx, b in enumerate(BADGES_REQUIREMENTS):
                r = idx // 5
                c = idx % 5
                bx_pos = badge_box_x + (c * 196)
                by_pos = badge_box_y + (r * 85)

                unlocked = b["title"] in self.unlocked_badges_cache
                box_color = COLORS["mint_green"] if unlocked else (235, 230, 230)
                text_color = COLORS["text"] if unlocked else (160, 150, 150)

                pygame.draw.rect(self.screen, box_color, (bx_pos, by_pos, 185, 75), border_radius=8)
                pygame.draw.rect(self.screen, COLORS["shadow"], (bx_pos, by_pos, 185, 75), 1, border_radius=8)

                b_title = b["title"] if unlocked else "🔒 Locked"
                self.screen.blit(self.tiny_font.render(b_title, True, text_color), (bx_pos + 8, by_pos + 12))
                self.screen.blit(self.badge_desc_font.render(b["desc"], True, text_color), (bx_pos + 8, by_pos + 42))

            self.draw_button(pygame.Rect(410, 585, 280, 55), "Proceed to Market Shop 🛒", COLORS["berry_red"], COLORS["cream"], action="go_to_shop")
            return

        # 3. WHOLESALE MARKET SHOP SCREEN
        if self.show_shop_phase:
            self.draw_panel(40, 40, 1020, 620, "Cottage Valley Wholesale Market")
            desc = self.small_font.render(
                f"Wallet: ${self.money}  | Flavors: {len(self.unlocked_flavors)}/30  | Frostings: {len(self.unlocked_frostings)}/12  | Toppings: {len(self.unlocked_garnishes)}/12",
                True, COLORS["text"])
            self.screen.blit(desc, (70, 80))

            # Left side Upgrades
            pygame.draw.rect(self.screen, COLORS["cream"], (60, 120, 480, 440), border_radius=16)
            upgrades_keys = list(self.upgrades.keys())
            for i in range(4):
                idx = self.shop_scroll_offset + i
                if idx >= len(upgrades_keys): break
                key = upgrades_keys[idx]
                item = self.upgrades[key]
                y_pos = 140 + (i * 100)

                bg_card_color = COLORS["mint_green"] if item["active"] else COLORS["accent"]
                pygame.draw.rect(self.screen, bg_card_color, (75, y_pos, 450, 88), border_radius=8)
                self.screen.blit(self.tiny_font.render(f"{item['name']} (${item['cost']})", True, COLORS["text"]), (90, y_pos + 18))
                self.screen.blit(self.shop_desc_font.render(item["desc"], True, COLORS["text"]), (90, y_pos + 50))

                if not item["active"]:
                    self.draw_button(pygame.Rect(430, y_pos + 20, 80, 48), "Buy", COLORS["mint_green"], action=f"buyupgrade_{key}")
                else:
                    self.screen.blit(self.tiny_font.render("Owned", True, COLORS["berry_red"]), (440, y_pos + 35))

            self.draw_button(pygame.Rect(60, 570, 230, 45), "▲ Scroll Up", COLORS["accent"], action="scroll_up")
            self.draw_button(pygame.Rect(310, 570, 230, 45), "▼ Scroll Down", COLORS["accent"], action="scroll_down")

            # Right side panel with tabs: Flavors / Frostings / Garnishes
            pygame.draw.rect(self.screen, COLORS["cream"], (560, 120, 480, 440), border_radius=16)
            # Tab buttons
            tab_btns = [("flavors", "🧁 Flavors"), ("frostings", "🍦 Frostings"), ("garnishes", "✨ Toppings")]
            for ti, (tkey, tlabel) in enumerate(tab_btns):
                tc = COLORS["berry_red"] if self.shop_right_tab == tkey else COLORS["accent"]
                tc_txt = COLORS["cream"] if self.shop_right_tab == tkey else COLORS["text"]
                self.draw_button(pygame.Rect(565 + ti * 155, 125, 148, 36), tlabel, tc, tc_txt, action=f"shop_tab_{tkey}")

            if self.shop_right_tab == "flavors":
                locked_list = [f for f in FLAVORS if f not in self.unlocked_flavors]
                for idx, item_name in enumerate(locked_list[self.shop_right_scroll:self.shop_right_scroll + 5]):
                    y_pos = 175 + (idx * 72)
                    cost = self.flavor_costs[item_name]
                    if self.upgrades["solar"]["active"]: cost = int(cost * 0.5)
                    pygame.draw.rect(self.screen, COLORS["accent"], (575, y_pos, 450, 62), border_radius=8)
                    self.screen.blit(self.tiny_font.render(f"🧁 {item_name} (${cost})", True, COLORS["text"]), (590, y_pos + 22))
                    self.draw_button(pygame.Rect(910, y_pos + 10, 100, 40), "Unlock", COLORS["mint_green"], action=f"unlockflv_{item_name}")
            elif self.shop_right_tab == "frostings":
                locked_list = [f for f in ALL_FROSTINGS if f not in self.unlocked_frostings]
                for idx, item_name in enumerate(locked_list[self.shop_right_scroll:self.shop_right_scroll + 5]):
                    y_pos = 175 + (idx * 72)
                    cost = self.frosting_costs.get(item_name, 50)
                    pygame.draw.rect(self.screen, (220, 240, 255), (575, y_pos, 450, 62), border_radius=8)
                    self.screen.blit(self.tiny_font.render(f"🍦 {item_name} (${cost})", True, COLORS["text"]), (590, y_pos + 22))
                    self.draw_button(pygame.Rect(910, y_pos + 10, 100, 40), "Unlock", COLORS["mint_green"], action=f"unlockfrost_{item_name}")
            elif self.shop_right_tab == "garnishes":
                locked_list = [g for g in ALL_GARNISHES if g not in self.unlocked_garnishes]
                for idx, item_name in enumerate(locked_list[self.shop_right_scroll:self.shop_right_scroll + 5]):
                    y_pos = 175 + (idx * 72)
                    cost = self.garnish_costs.get(item_name, 40)
                    pygame.draw.rect(self.screen, (240, 255, 230), (575, y_pos, 450, 62), border_radius=8)
                    self.screen.blit(self.tiny_font.render(f"✨ {item_name} (${cost})", True, COLORS["text"]), (590, y_pos + 22))
                    self.draw_button(pygame.Rect(910, y_pos + 10, 100, 40), "Unlock", COLORS["mint_green"], action=f"unlockgarnish_{item_name}")

            self.draw_button(pygame.Rect(565, 540, 215, 40), "▲ Scroll Up", COLORS["accent"], action="right_scroll_up")
            self.draw_button(pygame.Rect(790, 540, 240, 40), "▼ Scroll Down", COLORS["accent"], action="right_scroll_down")

            self.draw_button(pygame.Rect(410, 610, 280, 50), "☀️ Begin Next Shift", COLORS["berry_red"], COLORS["cream"], action="next_day")
            return

        # 4. MAIN GAMEPLAY CAFE DASHBOARD
        self.draw_panel(20, 20, 700, 380, "Kitchen Counter")
        self.draw_button(pygame.Rect(40, 45, 140, 36), "⏸ Pause Cafe", COLORS["accent"], action="toggle_pause")

        plate_x, plate_y = 140, 220
        pygame.draw.ellipse(self.screen, COLORS["mint_green"], (plate_x - 75, plate_y + 12, 150, 45))
        pygame.draw.ellipse(self.screen, COLORS["cream"], (plate_x - 65, plate_y + 15, 130, 35))
        self.draw_pastry_visual(plate_x, plate_y)

        # 5. CUSTOMER TICKETS WITH HQ GRAPHICS
        active_customer = self.active_slots[self.selected_slot_index]
        for idx in range(self.num_slots):
            slot = self.active_slots[idx]
            slot_rect = pygame.Rect(300 + (idx * 132), 70, 125, 110)
            border_col = COLORS["berry_red"] if idx == self.selected_slot_index else COLORS["shadow"]
            bg_col = COLORS["cream"] if idx == self.selected_slot_index else (245, 240, 240)

            pygame.draw.rect(self.screen, bg_col, slot_rect, border_radius=12)
            pygame.draw.rect(self.screen, border_col, slot_rect, 3 if idx == self.selected_slot_index else 1, border_radius=12)

            # Mini High Quality Sprite inside queue
            self.draw_character_slot(362 + (idx * 132), 115, slot["profile"], size="small")

            max_patience = 120 if self.upgrades["ads"]["active"] else 100
            p_bar_w = int(95 * (slot["patience"] / max_patience))
            p_bar_w = max(0, min(95, p_bar_w))
            pygame.draw.rect(self.screen, COLORS["shadow"], (315 + (idx * 132), 165, 95, 6), border_radius=3)
            pygame.draw.rect(self.screen, COLORS["berry_red"], (315 + (idx * 132), 165, p_bar_w, 6), border_radius=3)
            self.draw_button(pygame.Rect(300 + (idx * 132), 70, 125, 110), "", (0,0,0,0), action=f"selectslot_{idx}")

        # ACTIVE CUSTOMER DIALOG PORTRAIT ENGINE
        bubble = pygame.Rect(300, 195, 400, 190)
        pygame.draw.rect(self.screen, COLORS["cream"], bubble, border_radius=18)
        pygame.draw.rect(self.screen, COLORS["mint_green"], bubble, 1, border_radius=18)

        # Displays the crisp high resolution artwork portrait right inside bubble card
        self.draw_character_slot(355, 275, active_customer["profile"], size="large")

        dial_lines = [active_customer["dialogue"][i:i+32] for i in range(0, len(active_customer["dialogue"]), 32)]
        for i, d_l in enumerate(dial_lines[:2]):
            self.screen.blit(self.tiny_font.render(d_l, True, COLORS["text"]), (420, 205 + (i * 15)))

        self.screen.blit(self.tiny_font.render(f"• Flavor: {active_customer['order']['flavor']}", True, COLORS["text"]), (420, 245))
        self.screen.blit(self.tiny_font.render(f"• Frosting: {active_customer['order']['frosting']}", True, COLORS["text"]), (420, 265))
        self.screen.blit(self.tiny_font.render(f"• Garnish: {active_customer['order']['garnish']}", True, COLORS["text"]), (420, 285))

        made_str = f"On Plate: {self.selected_flavor or '?'}+{self.selected_frosting or '?'}+{self.selected_garnish or '?'}"
        self.screen.blit(self.tiny_font.render(made_str, True, COLORS["berry_red"]), (315, 355))

        # 6. MOBILE TABBED SIDEBAR SELECTION SYSTEM
        sidebar = pygame.Rect(740, 20, 340, 660)
        self.draw_panel(sidebar.x, sidebar.y, sidebar.width, sidebar.height, "Menu Kitchen Options")
        bx = sidebar.x + 15
        tab_y = sidebar.y + 45

        # Render the tab controllers
        sponge_col = COLORS["berry_red"] if self.active_sidebar_tab == "sponge" else COLORS["accent"]
        self.draw_button(pygame.Rect(bx, tab_y, 95, 38), "🍰 Base", sponge_col, COLORS["cream"] if self.active_sidebar_tab == "sponge" else COLORS["text"], action="tab_sponge")

        frost_col = COLORS["berry_red"] if self.active_sidebar_tab == "frosting" else COLORS["accent"]
        self.draw_button(pygame.Rect(bx + 102, tab_y, 95, 38), "🧁 Frost", frost_col, COLORS["cream"] if self.active_sidebar_tab == "frosting" else COLORS["text"], action="tab_frosting")

        garnish_col = COLORS["berry_red"] if self.active_sidebar_tab == "garnish" else COLORS["accent"]
        self.draw_button(pygame.Rect(bx + 204, tab_y, 95, 38), "✨ Top", garnish_col, COLORS["cream"] if self.active_sidebar_tab == "garnish" else COLORS["text"], action="tab_garnish")

        start_y = tab_y + 55
        if self.active_sidebar_tab == "sponge":
            self.screen.blit(self.tiny_font.render("1. Select Cake Base Sponge:", True, COLORS["text"]), (bx, start_y))
            flavors_page_start = self.sponge_page * 10
            visible_flavors = FLAVORS[flavors_page_start:flavors_page_start + 10]
            for i, name in enumerate(visible_flavors):
                col = i % 2
                row = i // 2
                is_unlocked = name in self.unlocked_flavors
                btn_txt = name if is_unlocked else f"🔒 {name[:8]}"
                btn_color = COLORS["accent"] if is_unlocked else (220, 220, 220)
                self.draw_button(pygame.Rect(bx + (col * 155), start_y + 25 + (row * 50), 145, 42), btn_txt, btn_color, action=f"flavor_{name}" if is_unlocked else "locked_flavor_click")

            # Flip menu sheet tracker (3 pages for 30 flavors)
            page_label = f"Flip Flavor Page ({self.sponge_page + 1}/3)"
            self.draw_button(pygame.Rect(bx, start_y + 285, 300, 42), page_label, COLORS["mint_green"], action="toggle_sponge_page")

        elif self.active_sidebar_tab == "frosting":
            self.screen.blit(self.tiny_font.render("2. Select Frosting Blend:", True, COLORS["text"]), (bx, start_y))
            for i, name in enumerate(self.unlocked_frostings):
                col = i % 2
                row = i // 2
                self.draw_button(pygame.Rect(bx + (col * 155), start_y + 25 + (row * 55), 145, 46), name, COLORS["mint_green"], action=f"frost_{name}")

        elif self.active_sidebar_tab == "garnish":
            self.screen.blit(self.tiny_font.render("3. Select Outer Garnish:", True, COLORS["text"]), (bx, start_y))
            for i, name in enumerate(self.unlocked_garnishes):
                col = i % 2
                row = i // 2
                self.draw_button(pygame.Rect(bx + (col * 155), start_y + 25 + (row * 55), 145, 46), name, COLORS["shadow"], COLORS["cream"], action=f"garnish_{name}")

        # Serve Button anchored at base of layout
        self.draw_button(pygame.Rect(bx, sidebar.y + 590, 300, 52), "🧁 Serve Customer Plate", COLORS["berry_red"], COLORS["cream"], action="serve")

        # 7. BOTTOM HUD AREA
        self.draw_panel(20, 415, 700, 265, "Baking Dashboard")
        stats_line = f"Tag: {self.baker_name}  |  Wallet: ${self.money}  |  Combo: x{self.combo}  |  Time: {self.time_left}s"
        self.screen.blit(self.small_font.render(stats_line, True, COLORS["text"]), (40, 455))
        self.screen.blit(self.tiny_font.render(f"📢 System: {self.message}", True, COLORS["berry_red"]), (40, 495))

        self.draw_button(pygame.Rect(40, 545, 310, 45), "⏩ Trash & Skip Order", COLORS["cream"], action="skip")
        self.draw_button(pygame.Rect(370, 545, 320, 45), "🔄 Reset Server Engine", (240, 200, 200), COLORS["text"], action="restart_game")

        if self.is_paused:
            pause_overlay = pygame.Rect(20, 20, 700, 380)
            pygame.draw.rect(self.screen, (255, 235, 235), pause_overlay, border_radius=24)
            p_lbl = self.title_font.render("☕ Cafe Paused ☕", True, COLORS["berry_red"])
            self.screen.blit(p_lbl, p_lbl.get_rect(center=(370, 200)))
            self.draw_button(pygame.Rect(40, 45, 140, 36), "▶ Resume Game", COLORS["accent"], action="toggle_pause")

        if self.game_over:
            overlay = pygame.Rect(260, 140, 520, 220)
            pygame.draw.rect(self.screen, COLORS["cream"], overlay, border_radius=24)
            pygame.draw.rect(self.screen, COLORS["berry_red"], overlay, 4, border_radius=24)
            end_text = self.font.render("Shift Complete!", True, COLORS["berry_red"])
            self.screen.blit(end_text, (460, 170))
            self.draw_button(pygame.Rect(340, 240, 360, 55), "See Badges & Milestone Tracker", COLORS["mint_green"], action="trigger_milestone_tab")

    def handle_click(self, pos):
        for rect, action in list(self.buttons):
            if rect.collidepoint(pos):
                if action == "activate_typing":
                    self.typing_active = True
                    return
                else:
                    self.typing_active = False

                if action == "toggle_pause":
                    if not self.game_over and not self.show_intro and not self.show_shop_phase and not self.show_badge_tab_phase:
                        self.is_paused = not self.is_paused
                    return

                if self.is_paused and action != "toggle_pause": return
                if action == "restart_game":
                    self.reset_game_state()
                    return
                if action == "start_game":
                    self.show_intro = False
                    return
                if action == "trigger_milestone_tab":
                    self.show_badge_tab_phase = True
                    return
                if action == "go_to_shop":
                    self.show_badge_tab_phase = False
                    self.show_shop_phase = True
                    return
                if action == "scroll_up":
                    self.shop_scroll_offset = max(0, self.shop_scroll_offset - 1)
                    return
                if action == "scroll_down":
                    self.shop_scroll_offset = min(len(self.upgrades) - 4, self.shop_scroll_offset + 1)
                    return
                if action == "right_scroll_up":
                    self.shop_right_scroll = max(0, self.shop_right_scroll - 1)
                    return
                if action == "right_scroll_down":
                    self.shop_right_scroll += 1
                    return
                if action.startswith("shop_tab_"):
                    self.shop_right_tab = action.split("shop_tab_")[1]
                    self.shop_right_scroll = 0
                    return
                if action == "tab_sponge":
                    self.active_sidebar_tab = "sponge"
                    return
                if action == "tab_frosting":
                    self.active_sidebar_tab = "frosting"
                    return
                if action == "tab_garnish":
                    self.active_sidebar_tab = "garnish"
                    return
                if action == "toggle_sponge_page":
                    self.sponge_page = (self.sponge_page + 1) % 3
                    return
                if action.startswith("selectslot_"):
                    self.selected_slot_index = int(action.split("_")[1])
                    return
                if action.startswith("buyupgrade_"):
                    key = action.split("_")[1]
                    item = self.upgrades[key]
                    if self.money >= item["cost"] and not item["active"]:
                        self.money -= item["cost"]
                        item["active"] = True
                        self.message = f"Bought: {item['name']}!"
                        self.check_badges()
                    return
                if action.startswith("unlockflv_"):
                    flv_name = action.split("unlockflv_")[1]
                    cost = self.flavor_costs[flv_name]
                    if self.upgrades["solar"]["active"]: cost = int(cost * 0.5)
                    if self.money >= cost and flv_name not in self.unlocked_flavors:
                        self.money -= cost
                        self.unlocked_flavors.append(flv_name)
                        self.message = f"Unlocked: {flv_name}!"
                        self.check_badges()
                    return
                if action.startswith("unlockfrost_"):
                    frost_name = action.split("unlockfrost_")[1]
                    cost = self.frosting_costs.get(frost_name, 50)
                    if self.money >= cost and frost_name not in self.unlocked_frostings:
                        self.money -= cost
                        self.unlocked_frostings.append(frost_name)
                        self.message = f"Unlocked Frosting: {frost_name}!"
                        self.check_badges()
                    return
                if action.startswith("unlockgarnish_"):
                    garn_name = action.split("unlockgarnish_")[1]
                    cost = self.garnish_costs.get(garn_name, 40)
                    if self.money >= cost and garn_name not in self.unlocked_garnishes:
                        self.money -= cost
                        self.unlocked_garnishes.append(garn_name)
                        self.message = f"Unlocked Topping: {garn_name}!"
                        self.check_badges()
                    return
                if action == "next_day":
                    self.show_shop_phase = False
                    self.time_left = self.shift_max_time
                    if self.upgrades["timer"]["active"]: self.time_left += 15
                    self.game_over = False
                    for idx in range(self.num_slots):
                        self.next_slot_order(idx)
                    return
                if action.startswith("flavor_") or action.startswith("frost_") or action.startswith("garnish_"):
                    if action.startswith("flavor_"): self.selected_flavor = action.split("_")[1]
                    elif action.startswith("frost_"): self.selected_frosting = action.split("_")[1]
                    elif action.startswith("garnish_"): self.selected_garnish = action.split("_")[1]
                    return
                if action == "locked_flavor_click":
                    self.message = "Recipe locked! Buy it in market."
                    return
                if action == "serve":
                    if self.selected_flavor and self.selected_frosting and self.selected_garnish:
                        self.evaluate_order(self.selected_flavor, self.selected_frosting, self.selected_garnish)
                        self.next_slot_order(self.selected_slot_index)
                    else:
                        self.message = "Missing plate parts!"
                    return
                if action == "skip":
                    self.combo = 0
                    self.message = "Ticket discarded."
                    self.next_slot_order(self.selected_slot_index)
                    return

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if self.show_intro and self.typing_active:
                        if event.key == pygame.K_BACKSPACE:
                            self.baker_name = self.baker_name[:-1]
                        elif event.key == pygame.K_RETURN:
                            self.typing_active = False
                        else:
                            if len(self.baker_name) < 18 and event.unicode.isprintable():
                                self.baker_name += event.unicode

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.handle_click(event.pos)

            if not self.game_over and not self.show_intro and not self.show_shop_phase and not self.show_badge_tab_phase and not self.is_paused:
                now = pygame.time.get_ticks()
                if now - self.last_tick >= 1000:
                    self.time_left -= 1

                    passive_cash = 0
                    if self.upgrades["planter"]["active"]: passive_cash += 2
                    if self.upgrades["display_case"]["active"]: passive_cash += 4
                    if self.upgrades["ovens"]["active"]: passive_cash += 8
                    if self.upgrades["drone"]["active"]: passive_cash += 15
                    if self.upgrades["cosmic_oven"]["active"]: passive_cash += 35
                    self.money += passive_cash
                    if passive_cash > 0: self.check_badges()

                    patience_drain = 4
                    if self.upgrades["espresso"]["active"]: patience_drain = 2
                    if self.upgrades["radio"]["active"]: patience_drain = int(patience_drain * 0.9)

                    for idx in range(self.num_slots):
                        self.active_slots[idx]["patience"] -= patience_drain
                        if self.active_slots[idx]["patience"] <= 0:
                            self.combo = 0
                            self.message = f"{self.active_slots[idx]['profile']['name']} left line!"
                            self.next_slot_order(idx)

                    self.last_tick = now
                if self.time_left <= 0:
                    self.game_over = True
                    self.message = "Shift ended!"

            self.draw()
            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        if not self.is_web_runtime:
            sys.exit()
        return

if __name__ == "__main__":
    BakeryGame().run()
